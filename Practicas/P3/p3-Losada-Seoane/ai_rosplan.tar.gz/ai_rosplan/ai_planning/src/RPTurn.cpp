#include "ai_planning/RPTurn.h"

namespace KCL_rosplan {

    // constructor
    RPTurn::RPTurn(ros::NodeHandle &nh) {
        nh_ = nh;
    }

    bool RPTurn::concreteCallback(const rosplan_dispatch_msgs::ActionDispatch::ConstPtr& msg) {
        // INSERTA TU CODIGO AQUI
        ros::Subscriber sub_odometry = nh_.subscribe("/Robot1/odom", 1, &RPTurn::odomCallback, this);
        ros::Publisher velocity_publisher = nh_.advertise<geometry_msgs::Twist>("/Robot1/cmd_vel",1);    

        std::string s = msg->parameters[1].value;
        std::string d = msg->parameters[2].value;

	ROS_INFO_STREAM("SOURCE (" << s << ") TARGET (" << d << ")");

	float target_rad = 0.0;
	if(d == "left"){
            target_rad = -M_PI/2;
        }else if(d == "down"){
            target_rad = 0;
        }else if(d == "right"){
           target_rad = M_PI/2;
        }else if(d == "up"){
            target_rad = M_PI;
	}

	ros::Rate rate(3);
        geometry_msgs::Twist vel_msg;
	float angular_velocity = 0.2;
	if((target_rad < 0 && current_pose.theta < 0) || (target_rad >= 0 && current_pose.theta >= 0)){
                if(current_pose.theta > target_rad){
                    vel_msg.angular.z = -angular_velocity;
                }else{
                    vel_msg.angular.z = angular_velocity;
                }
	}else{
		if(((M_PI - fabs(target_rad)) + (M_PI - fabs(current_pose.theta))) < ((fabs(target_rad) - 0) + (fabs(current_pose.theta) - 0))){
			if(current_pose.theta > 0) vel_msg.angular.z = angular_velocity;
			else vel_msg.angular.z = -angular_velocity;
		}else{
			if(current_pose.theta > 0) vel_msg.angular.z = -angular_velocity;
			else vel_msg.angular.z = angular_velocity;
		}
	}
        while(fabs(target_rad - current_pose.theta) > 0.05){  
    	    velocity_publisher.publish(vel_msg);
            ros::spinOnce();
            rate.sleep();
	}
        //After the loop, stops the robot
        vel_msg.angular.z = 0.0;
        //Force the robot to stop
        velocity_publisher.publish(vel_msg);
        rate.sleep();

        return true;
    }


    void RPTurn::odomCallback(const nav_msgs::OdometryConstPtr& msg)
    {
        // linear position
        current_pose.x = msg->pose.pose.position.x;
        current_pose.y = msg->pose.pose.position.y;

        // quaternion to RPY conversion
        tf::Quaternion q(
            msg->pose.pose.orientation.x,
            msg->pose.pose.orientation.y,
            msg->pose.pose.orientation.z,
            msg->pose.pose.orientation.w);
        tf::Matrix3x3 m(q);
        double roll, pitch, yaw;
        m.getRPY(roll, pitch, yaw);
        // angular position
        current_pose.theta = yaw;
    }

    
} // close namespace

int main(int argc, char **argv) {

    ros::init(argc, argv, "rosplan_interface_turn");

    ros::NodeHandle nh("~");

    // create PDDL action subscriber
    KCL_rosplan::RPTurn rpmb(nh);

    rpmb.runActionInterface();

    return 0;
}
